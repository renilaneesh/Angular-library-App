import { Books } from './books.model';

describe('Books', () => {
  it('should create an instance', () => {
    expect( Books).toBeTruthy();
  });
});
