export class Authors{
    constructor(
       public _id: string,
       public authorName: string,
       public description: string,
       public imageUrl:string,
       ){}
}