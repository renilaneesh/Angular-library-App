import { Authors } from './authors.model';

describe('Authors', () => {
  it('should create an instance', () => {
    expect( Authors).toBeTruthy();
  });
});
