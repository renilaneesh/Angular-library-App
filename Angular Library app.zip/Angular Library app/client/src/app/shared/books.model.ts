export class Books{
    constructor(
       public _id: string,
       public name: string,
       public code:number,
       public author:string,
       public count:number){}
}