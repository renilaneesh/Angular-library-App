export class AuthorModel{
    constructor(
    public authorName : string,
    public majorworks : string,
    public description : string,
    public imageUrl : string){}
}